/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Negocio;

public class Ficha {
    private int ladoA;
    private int ladoB;

    public Ficha(int ladoA, int ladoB) {
        this.ladoA = ladoA;
        this.ladoB = ladoB;
    }

    // Getters y Setters
    public int getLadoA() { return ladoA; }
    public int getLadoB() { return ladoB; }
    
    // Método CRUCIAL para el dominó: Voltear la ficha
    // Esto intercambia los valores: [2|5] se convierte en [5|2]
    public void voltear() {
        int temp = this.ladoA;
        this.ladoA = this.ladoB;
        this.ladoB = temp;
    }

    public boolean esIgual(Ficha otra) {
        // Compara si es la misma ficha (considerando ambos sentidos)
        return (this.ladoA == otra.ladoA && this.ladoB == otra.ladoB) ||
               (this.ladoA == otra.ladoB && this.ladoB == otra.ladoA);
    }

    @Override
    public String toString() {
        return "[" + ladoA + "|" + ladoB + "]";
    }
}
