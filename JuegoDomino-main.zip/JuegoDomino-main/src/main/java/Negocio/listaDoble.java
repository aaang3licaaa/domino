/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Negocio;

public class listaDoble {
    private nodoDoble primero;
    private nodoDoble ultimo;
    private int cantidad;

    public listaDoble() {
        this.primero = null;
        this.ultimo = null;
        this.cantidad = 0;
    }

    public boolean vacia() { return cantidad == 0; }
    public int getCantidad() { return cantidad; }

    // --- MÉTODOS DE INSERCIÓN ---
    public void insertarInicio(Ficha f) {
        nodoDoble nuevo = new nodoDoble(f);
        if (vacia()) {
            primero = nuevo;
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(primero);
            primero.setAnterior(nuevo);
            primero = nuevo;
        }
        cantidad++;
    }

    public void insertarFinal(Ficha f) {
        nodoDoble nuevo = new nodoDoble(f);
        if (vacia()) {
            primero = nuevo;
            ultimo = nuevo;
        } else {
            ultimo.setSiguiente(nuevo);
            nuevo.setAnterior(ultimo);
            ultimo = nuevo;
        }
        cantidad++;
    }
    
    // --- CONSULTA DE VALORES EXTREMOS ---
    public int getValorIzquierda() {
        if (vacia()) return -1;
        return primero.getDato().getLadoA();
    }

    public int getValorDerecha() {
        if (vacia()) return -1;
        return ultimo.getDato().getLadoB();
    }

    // --- GESTIÓN DE ELIMINACIÓN ---

    // 1. Eliminar por Objeto
    public boolean eliminarFicha(Ficha fichaBuscada) {
        if (vacia()) return false;
        nodoDoble aux = primero;
        while (aux != null) {
            if (aux.getDato().esIgual(fichaBuscada)) {
                if (aux == primero) eliminarInicio();
                else if (aux == ultimo) eliminarFinal();
                else {
                    aux.getAnterior().setSiguiente(aux.getSiguiente());
                    aux.getSiguiente().setAnterior(aux.getAnterior());
                    cantidad--;
                }
                return true;
            }
            aux = aux.getSiguiente();
        }
        return false;
    }

    // 2. Eliminar Inicio
    public Ficha eliminarInicio() {
        if (vacia()) return null;
        Ficha dato = primero.getDato();
        if (primero == ultimo) {
            primero = null;
            ultimo = null;
        } else {
            primero = primero.getSiguiente();
            primero.setAnterior(null);
        }
        cantidad--;
        return dato;
    }
    
    // 3. Eliminar Final
    public Ficha eliminarFinal() {
        if (vacia()) return null;
        Ficha dato = ultimo.getDato();
        if (primero == ultimo) {
            primero = null;
            ultimo = null;
        } else {
            ultimo = ultimo.getAnterior();
            ultimo.setSiguiente(null);
        }
        cantidad--;
        return dato;
    }
    
    // --- MÉTODOS POR ÍNDICE (Corrección Importante) ---

    public Ficha obtenerPorIndice(int indice) {
        if (indice < 0 || indice >= cantidad) return null;
        nodoDoble aux = primero;
        for (int i = 0; i < indice; i++) {
            aux = aux.getSiguiente();
        }
        return aux.getDato();
    }

    public Ficha eliminarPorIndice(int indice) {
        if (indice < 0 || indice >= cantidad || vacia()) return null;

        if (indice == 0) return eliminarInicio();
        if (indice == cantidad - 1) return eliminarFinal();

        // Caso medio
        nodoDoble aux = primero;
        for (int i = 0; i < indice; i++) {
            aux = aux.getSiguiente();
        }
        
        Ficha datoEliminado = aux.getDato();
        // Reconectar punteros
        aux.getAnterior().setSiguiente(aux.getSiguiente());
        aux.getSiguiente().setAnterior(aux.getAnterior());
        cantidad--;
        
        return datoEliminado;
    }

    @Override
    public String toString() { return listar(); }

    public String listar() {
        StringBuilder sb = new StringBuilder();
        nodoDoble aux = primero;
        while (aux != null) {
            sb.append(aux.getDato().toString());
            if (aux.getSiguiente() != null) sb.append(" "); 
            aux = aux.getSiguiente();
        }
        return sb.toString();
    }
}