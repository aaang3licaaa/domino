/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Negocio;
import java.util.ArrayList;
import java.util.Collections;

public class juegoDomino {
    private listaDoble manoUsuario;
    private listaDoble manoMaquina;
    private listaDoble mesa;
    
    public juegoDomino() {
        this.manoUsuario = new listaDoble();
        this.manoMaquina = new listaDoble();
        this.mesa = new listaDoble();
    }

    // --- CORRECCIÓN 1: Método para iniciar y repartir ---
    public void iniciarJuego() {
        // 1. Generar fichas de Doble 9 (55 fichas)
        ArrayList<Ficha> pozo = new ArrayList<>();
        for (int i = 0; i <= 9; i++) {
            for (int j = i; j <= 9; j++) {
                pozo.add(new Ficha(i, j));
            }
        }

        // 2. Barajar
        Collections.shuffle(pozo);

        // 3. Ajustar a 53 fichas (requisito de pizarra)
        while (pozo.size() > 53) {
            pozo.remove(0);
        }

        // 4. Repartir 26 al Usuario
        for (int i = 0; i < 26; i++) {
            if (!pozo.isEmpty()) manoUsuario.insertarFinal(pozo.remove(0));
        }

        // 5. Repartir 26 a la Máquina
        for (int i = 0; i < 26; i++) {
            if (!pozo.isEmpty()) manoMaquina.insertarFinal(pozo.remove(0));
        }
        
        // La ficha que sobra (si hay) se queda en el pozo o se inicia mesa.
        // Opcional: Iniciar mesa si quieres
        // if(!pozo.isEmpty()) mesa.insertarInicio(pozo.remove(0));
    }

    // --- CORRECCIÓN 2: Getters necesarios para la UI ---
    public listaDoble getManoUsuario() { return manoUsuario; }
    public listaDoble getManoMaquina() { return manoMaquina; }
    public listaDoble getMesa() { return mesa; }

    // --- LÓGICA DEL JUGADOR ---
    public boolean turnoUsuario(int indicePosicion, String ladoDestino) {
        Ficha ficha = manoUsuario.obtenerPorIndice(indicePosicion);
        if (ficha == null) return false;

        boolean jugadaValida = false;

        if (mesa.vacia()) {
            mesa.insertarInicio(manoUsuario.eliminarPorIndice(indicePosicion));
            return true;
        }

        int valorExtremo = -1;

        if (ladoDestino.equalsIgnoreCase("IZQUIERDA")) {
            valorExtremo = mesa.getValorIzquierda();
            if (ficha.getLadoB() == valorExtremo) {
                jugadaValida = true;
            } else if (ficha.getLadoA() == valorExtremo) {
                ficha.voltear();
                jugadaValida = true;
            }

            if (jugadaValida) {
                manoUsuario.eliminarPorIndice(indicePosicion);
                mesa.insertarInicio(ficha);
            }

        } else if (ladoDestino.equalsIgnoreCase("DERECHA")) {
            valorExtremo = mesa.getValorDerecha();
            if (ficha.getLadoA() == valorExtremo) {
                jugadaValida = true;
            } else if (ficha.getLadoB() == valorExtremo) {
                ficha.voltear();
                jugadaValida = true;
            }

            if (jugadaValida) {
                manoUsuario.eliminarPorIndice(indicePosicion);
                mesa.insertarFinal(ficha);
            }
        }
        return jugadaValida;
    }
    
    // --- LÓGICA DE LA MÁQUINA ---
    public boolean turnoMaquina() {
        if (mesa.vacia()) {
            Ficha f = manoMaquina.eliminarInicio();
            mesa.insertarInicio(f);
            System.out.println("Máquina inicia la mesa con: " + f);
            return true;
        }

        int valIzq = mesa.getValorIzquierda();
        int valDer = mesa.getValorDerecha();
        int cantidadFichas = manoMaquina.getCantidad();

        for (int i = 0; i < cantidadFichas; i++) {
            Ficha actual = manoMaquina.obtenerPorIndice(i);

            // Intentar Izquierda
            if (actual.getLadoB() == valIzq || actual.getLadoA() == valIzq) {
                if (actual.getLadoA() == valIzq) actual.voltear();
                manoMaquina.eliminarPorIndice(i);
                mesa.insertarInicio(actual);
                System.out.println("Máquina jugó Izquierda: " + actual);
                return true;
            }

            // Intentar Derecha
            if (actual.getLadoA() == valDer || actual.getLadoB() == valDer) {
                if (actual.getLadoB() == valDer) actual.voltear();
                manoMaquina.eliminarPorIndice(i);
                mesa.insertarFinal(actual);
                System.out.println("Máquina jugó Derecha: " + actual);
                return true;
            }
        }
        System.out.println("Máquina PASA TURNO");
        return false;
    }
}
