/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Presentacion;
import Negocio.Ficha;
import Negocio.juegoDomino; // Asegúrate que coincida mayuscula/minuscula con tu clase
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
/**
 *
 * @author FABIAN
 */
public class Presentacion extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Presentacion.class.getName());
    juegoDomino juego;
    /**
     * Creates new form Presentacion
     */
    public Presentacion() {
        initComponents();
        // 1. Configuraciones visuales iniciales
        this.setTitle("Domino - Proyecto Final");
        this.setLocationRelativeTo(null); // Centrar ventana
        
        // Aseguramos que el panel de la mano tenga FlowLayout para ordenar fichas
        panelMano.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        
        // 2. Iniciar el juego
        iniciarJuegoNuevo();
    }
    private void iniciarJuegoNuevo() {
        juego = new juegoDomino();
        juego.iniciarJuego(); // Baraja y reparte
        actualizarPantalla(); // Dibuja todo por primera vez
    }
    private void actualizarPantalla() {
        // 1. ACTUALIZAR MESA
        if (juego.getMesa().vacia()) {
            txtMesa.setText("   [ MESA VACÍA - JUEGA TU PRIMERA FICHA ]");
        } else {
            txtMesa.setText(juego.getMesa().listar());
        }

        // 2. ACTUALIZAR TU MANO
        panelMano.removeAll(); // Si te marca error aquí es porque no hiciste el PASO 1
        
        int cantidad = juego.getManoUsuario().getCantidad();
        
        for (int i = 0; i < cantidad; i++) {
            Ficha f = juego.getManoUsuario().obtenerPorIndice(i);
            
           // --- AQUÍ EMPIEZA EL DISEÑO ---
            
            // 1. Texto con HTML para que se vea bonito (Números grandes)
            // Esto pone el numero Izq - una barra - numero Der
            String texto = "<html><font size='5'>" + f.getLadoA() + "</font>"
                         + "<font color='gray'> | </font>" 
                         + "<font size='5'>" + f.getLadoB() + "</font></html>";
            
            JButton btn = new JButton(texto);
            // Si es mula (doble), la pintamos de un color doradito
            if (f.getLadoA() == f.getLadoB()) {
                btn.setBackground(new Color(255, 255, 204)); // Amarillo pálido
                btn.setToolTipText("¡Es una Mula!"); // Texto al pasar el mouse
            } else {
                btn.setBackground(new Color(245, 245, 235)); // Blanco normal
            }
            
            // 2. Tamaño y Forma
            btn.setPreferredSize(new Dimension(80, 50)); // Rectangular
            
            // 3. Colores (Blanco Hueso y Texto Azul Oscuro)
            btn.setBackground(new Color(245, 245, 235)); // Color crema suave
            btn.setForeground(new Color(0, 0, 102));     // Azul oscuro para los números
            
            // 4. Borde "Bevel" (Biselado) para dar efecto 3D de relieve
            btn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.BLACK, 1), // Borde fino negro
                    BorderFactory.createRaisedBevelBorder()        // Relieve 3D
            ));
            
            // 5. Quitar el foco (el cuadradito punteado feo cuando haces clic)
            btn.setFocusPainted(false);
            
            // --- FIN DEL DISEÑO ---

            // Acción al hacer clic (Esto sigue igual que antes)
            final int indiceFicha = i; 
            btn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    gestionarTurnoJugador(indiceFicha);
                }
            });
            
            panelMano.add(btn);
        }
        
        // Refrescar cambios visuales (OBLIGATORIO)
        panelMano.revalidate();
        panelMano.repaint();
    }
    
    private void gestionarTurnoJugador(int indice) {
        // 1. Preguntar Lado
        String[] options = {"Izquierda", "Derecha", "Cancelar"};
        int seleccion = JOptionPane.showOptionDialog(
                this, 
                "¿Dónde deseas colocar la ficha?", 
                "Seleccionar Lado", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                options, 
                options[0]);

        if (seleccion == 2 || seleccion == -1) return; // Canceló

        String lado = (seleccion == 0) ? "IZQUIERDA" : "DERECHA";

        // 2. Intentar jugar en la lógica de negocio
        boolean exito = juego.turnoUsuario(indice, lado);

        if (exito) {
            // Si la jugada fue válida:
            actualizarPantalla(); // Refrescar para ver mi ficha puesta
            verificarGanador();   // ¿Gané?

            // 3. Turno de la Máquina (Inmediato)
            gestionarTurnoMaquina();
            
        } else {
            JOptionPane.showMessageDialog(this, 
                "❌ JUGADA INVÁLIDA\nLa ficha no coincide con el lado " + lado + " de la mesa.", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void gestionarTurnoMaquina() {
        // Pequeña pausa simulada o mensaje
        // (En aplicaciones reales se usa Timer, aquí lo hacemos directo)
        boolean jugo = juego.turnoMaquina();
        
        if (jugo) {
            actualizarPantalla();
            verificarGanador();
        } else {
            JOptionPane.showMessageDialog(this, "🤖 La Máquina PASA (No tiene fichas válidas).");
        }
    }
    
    private void verificarGanador() {
        if (juego.getManoUsuario().vacia()) {
            JOptionPane.showMessageDialog(this, "🏆 ¡FELICIDADES! ¡HAS GANADO!");
            iniciarJuegoNuevo(); // Reiniciar
        } else if (juego.getManoMaquina().vacia()) {
            JOptionPane.showMessageDialog(this, "💀 LA MÁQUINA HA GANADO.");
            iniciarJuegoNuevo(); // Reiniciar
        }
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txtMesa = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        panelMano = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtMesa.setEditable(false);
        txtMesa.setColumns(20);
        txtMesa.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        txtMesa.setRows(5);
        jScrollPane1.setViewportView(txtMesa);

        jButton1.setText("Reiniciar Juego");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(panelMano);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 923, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Presentacion().setVisible(true);
            }
        });
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel panelMano;
    private javax.swing.JTextArea txtMesa;
    // End of variables declaration//GEN-END:variables
}
