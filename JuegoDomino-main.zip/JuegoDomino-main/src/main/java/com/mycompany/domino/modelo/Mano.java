/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domino.modelo;
import Negocio.Ficha;
import Negocio.listaDoble;

/**
 *
 * @author angelica
 */
/**
 * Mano de un jugador (encapsula una listaDoble del paquete Negocio).
 * No se usan ArrayList; se respeta el estilo del TDA del docente.
 */
public class Mano {
    private listaDoble lista;

    public Mano() {
        lista = new listaDoble();
    }

    /**
     * Agrega una ficha al final de la mano.
     */
    public void agregar(Ficha f) {
        lista.insertarFinal(f);
    }

    /**
     * Quita y devuelve la ficha por índice (0-based). Retorna null si índice inválido.
     */
    public Ficha quitarPorIndice(int indice) {
        return lista.eliminarPorIndice(indice);
    }

    /**
     * Devuelve la cantidad de fichas en la mano.
     */
    public int tamaño() {
        return lista.getCantidad();
    }

    /**
     * Lista la mano con índices: "0:[a|b] 1:[c|d] ..."
     */
    public String listarConIndices() {
        StringBuilder sb = new StringBuilder();
        int tam = lista.getCantidad();
        for (int i = 0; i < tam; i++) {
            Ficha f = lista.obtenerPorIndice(i);
            sb.append(i).append(":").append(f.toString());
            if (i < tam - 1) sb.append("  ");
        }
        return sb.toString();
    }

    /**
     * Comprueba si existe alguna ficha que pueda jugar en los valores extremos.
     * izquierda y derecha son los valores extremos de la mesa (si la mesa está vacía
     * se interpreta que sí puede jugar).
     */
    public boolean tieneJugada(int izquierda, int derecha) {
        // Si la mesa está vacía (izquierda == -1), cualquiera puede colocar
        if (izquierda == -1 || derecha == -1) return true;
        int tam = lista.getCantidad();
        for (int i = 0; i < tam; i++) {
            Ficha f = lista.obtenerPorIndice(i);
            if (f == null) continue;
            if (f.getLadoA() == izquierda || f.getLadoB() == izquierda ||
                f.getLadoA() == derecha || f.getLadoB() == derecha) {
                return true;
            }
        }
        return false;
    }

    /**
     * Obtiene la ficha (sin quitar) por índice.
     */
    public Ficha obtener(int indice) {
        return lista.obtenerPorIndice(indice);
    }
}