/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domino.modelo;
import Negocio.Ficha;
/**
 *
 * @author angelica
 */
/**
 * Jugador CPU con estrategia simple: recorre la mano y coloca la primera ficha válida.
 */
public class JugadorCPU extends Jugador {

    public JugadorCPU(String nombre) {
        super(nombre);
    }

    @Override
    public boolean jugar(Mesa mesa) {
        int tam = mano.tamaño();
        for (int i = 0; i < tam; i++) {
            Ficha f = mano.obtener(i);
            if (f == null) continue;
            // intenta izquierda primero
            if (mesa.colocarIzquierda(f)) {
                mano.quitarPorIndice(i);
                System.out.println(nombre + " jugó " + f + " en la izquierda.");
                return true;
            }
            // intenta derecha
            if (mesa.colocarDerecha(f)) {
                mano.quitarPorIndice(i);
                System.out.println(nombre + " jugó " + f + " en la derecha.");
                return true;
            }
        }
        System.out.println(nombre + " no tiene jugada válida y pasa.");
        return false;
    }
}