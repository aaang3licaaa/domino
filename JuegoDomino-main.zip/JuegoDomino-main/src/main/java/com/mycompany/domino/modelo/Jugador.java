/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domino.modelo;
import Negocio.Ficha;

/**
 *
 * @author angelica
 */
/**
 * Clase base para jugadores.
 */
public abstract class Jugador {
    protected String nombre;
    protected Mano mano;

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.mano = new Mano();
    }

    public String getNombre() { return nombre; }

    public Mano getMano() { return mano; }

    /**
     * Comprueba si el jugador tiene alguna jugada respecto a la mesa.
     */
    public boolean tieneJugada(Mesa mesa) {
        int izq = mesa.valorIzquierda();
        int der = mesa.valorDerecha();
        return mano.tieneJugada(izq, der);
    }

    /**
     * Intentar jugar. Devuelve true si realizó una jugada, false si pasó.
     */
    public abstract boolean jugar(Mesa mesa);
}