/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domino.modelo;
import Negocio.Ficha;
import Negocio.listaDoble;

/**
 *
 * @author angelica
 */
/**
 * Mesa de juego, usa Negocio.listaDoble internamente.
 * Permite iniciar con una ficha y colocar por izquierda o derecha.
 * Las fichas insertadas en la mesa se crean como nuevas instancias para evitar
 * mutar la ficha original de la mano (se respeta la ficha original hasta que se
 * quite de la mano).
 */
public class Mesa {
    private listaDoble secuencia;

    public Mesa() {
        secuencia = new listaDoble();
    }

    /**
     * Coloca la primera ficha en la mesa.
     */
    public void iniciarCon(Ficha fInicial) {
        secuencia.insertarInicio(new Ficha(fInicial.getLadoA(), fInicial.getLadoB()));
    }

    /**
     * Devuelve el valor extremo izquierdo (ladoA del primer nodo) o -1 si vacía.
     */
    public int valorIzquierda() {
        return secuencia.getValorIzquierda();
    }

    /**
     * Devuelve el valor extremo derecho (ladoB del último nodo) o -1 si vacía.
     */
    public int valorDerecha() {
        return secuencia.getValorDerecha();
    }

    /**
     * Intenta colocar la ficha por la izquierda. NO quita la ficha de la mano;
     * solo inserta en la mesa en la orientación correcta. Devuelve true si fue válida.
     */
    public boolean colocarIzquierda(Ficha f) {
        int valIzq = valorIzquierda();
        if (valIzq == -1) {
            // mesa vacía
            secuencia.insertarInicio(new Ficha(f.getLadoA(), f.getLadoB()));
            return true;
        }
        // Queremos que la parte derecha de la ficha coincida con valIzq
        if (f.getLadoB() == valIzq) {
            secuencia.insertarInicio(new Ficha(f.getLadoA(), f.getLadoB()));
            return true;
        } else if (f.getLadoA() == valIzq) {
            // insertar volteada
            secuencia.insertarInicio(new Ficha(f.getLadoB(), f.getLadoA()));
            return true;
        }
        return false;
    }

    /**
     * Intenta colocar la ficha por la derecha. NO quita la ficha de la mano;
     * solo inserta en la mesa en la orientación correcta. Devuelve true si fue válida.
     */
    public boolean colocarDerecha(Ficha f) {
        int valDer = valorDerecha();
        if (valDer == -1) {
            // mesa vacía
            secuencia.insertarFinal(new Ficha(f.getLadoA(), f.getLadoB()));
            return true;
        }
        // Queremos que la parte izquierda de la ficha coincida con valDer
        if (f.getLadoA() == valDer) {
            secuencia.insertarFinal(new Ficha(f.getLadoA(), f.getLadoB()));
            return true;
        } else if (f.getLadoB() == valDer) {
            // insertar volteada
            secuencia.insertarFinal(new Ficha(f.getLadoB(), f.getLadoA()));
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return secuencia.listar();
    }
}