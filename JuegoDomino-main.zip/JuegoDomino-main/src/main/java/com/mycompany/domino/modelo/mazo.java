/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domino.modelo;
import Negocio.Ficha;
import Negocio.listaDoble;
import java.util.Random;
/**
 *
 * @author angelica
 */

/**
 * Mazo de fichas.
 * Genera el conjunto base (doble-9: 0..9, i<=j = 55 fichas) y elimina dos fichas
 * deterministas ([0|0] y [0|1]) para quedar en 53 fichas (regla del docente).
 * Luego mezcla con Fisher-Yates sobre un arreglo temporal y carga la listaDoble.
 */
public class mazo {
    private listaDoble fichas;
    private final Random rnd = new Random();

    public mazo() {
        fichas = new listaDoble();
        generarYAjustarA53();
    }

    private void generarYAjustarA53() {
        // Creamos un arreglo temporal de tamaño 53 (skip [0|0] y [0|1])
        Ficha[] arr = new Ficha[53];
        int idx = 0;
        for (int i = 0; i <= 9; i++) {
            for (int j = i; j <= 9; j++) {
                // Eliminamos [0|0] y [0|1] para ajustar a 53 fichas
                if ((i == 0 && j == 0) || (i == 0 && j == 1)) continue;
                arr[idx++] = new Ficha(i, j);
            }
        }
        // idx debería ser 53
        // Mezclamos el arreglo con Fisher-Yates
        for (int i = arr.length - 1; i > 0; i--) {
            int r = rnd.nextInt(i + 1);
            Ficha tmp = arr[i];
            arr[i] = arr[r];
            arr[r] = tmp;
        }
        // Cargamos la listaDoble con las fichas mezcladas
        for (Ficha f : arr) {
            fichas.insertarFinal(f);
        }
    }

    /**
     * Roba la ficha del inicio (primera de la lista). Devuelve null si vacío.
     */
    public Ficha robar() {
        return fichas.eliminarInicio();
    }

    public int tamaño() {
        return fichas.getCantidad();
    }

    public String listar() {
        return fichas.listar();
    }
}
