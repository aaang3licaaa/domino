/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.domino;
import com.mycompany.domino.modelo.*;
import Negocio.Ficha;
import java.util.Scanner;


/**
 *
 * @author FABIAN
 */
/**
 * Clase principal que orquesta el juego por consola.
 * Reparte 26 fichas al humano, 26 a la CPU y coloca 1 ficha inicial en la mesa.
 * Alterna turnos y aplica las reglas solicitadas:
 * - Si un jugador no puede jugar, pasa.
 * - Si ambos pasan consecutivamente -> empate.
 * - Si un jugador se queda sin fichas -> ese jugador gana.
 */
public class Domino {
    private mazo mazo;
    private JugadorHumano jugador;
    private JugadorCPU maquina;
    private Mesa mesa;

    public Domino() {
        mazo = new mazo();
        mesa = new Mesa();
        Scanner sc = new Scanner(System.in);
        jugador = new JugadorHumano("Humano", sc);
        maquina = new JugadorCPU("CPU");
    }

    /**
     * Reparte 26 fichas a cada jugador y coloca 1 ficha inicial en la mesa.
     */
    public void iniciarReparto() {
        // El mazo ya se inicializó con 53 fichas mezcladas
        System.out.println("Mazo inicial (tamaño): " + mazo.tamaño());
        // Repartir 26 fichas a cada uno
        for (int i = 0; i < 26; i++) {
            Ficha fHum = mazo.robar();
            if (fHum != null) jugador.getMano().agregar(fHum);
            Ficha fCpu = mazo.robar();
            if (fCpu != null) maquina.getMano().agregar(fCpu);
        }
        // Poner la ficha inicial en la mesa
        Ficha inicial = mazo.robar();
        if (inicial != null) {
            mesa.iniciarCon(inicial);
            System.out.println("Ficha inicial en mesa: " + inicial);
        } else {
            System.out.println("Error: no hay ficha para iniciar la mesa.");
        }
        System.out.println("Mano humano tamaño: " + jugador.getMano().tamaño()
                           + "  Mano CPU tamaño: " + maquina.getMano().tamaño());
    }

    /**
     * Bucle principal de turnos.
     */
    public void jugar() {
        boolean turnoHumano = true; // comienza humano
        int pasesConsecutivos = 0;

        while (true) {
            boolean realizado;
            if (turnoHumano) {
                System.out.println("\n--- Turno HUMANO ---");
                realizado = jugador.jugar(mesa);
            } else {
                System.out.println("\n--- Turno CPU ---");
                realizado = maquina.jugar(mesa);
            }

            if (realizado) pasesConsecutivos = 0;
            else pasesConsecutivos++;

            // Verificar victoria
            if (jugador.getMano().tamaño() == 0) {
                System.out.println("¡Has ganado! Te quedaste sin fichas.");
                break;
            } else if (maquina.getMano().tamaño() == 0) {
                System.out.println("La CPU se quedó sin fichas. La CPU gana.");
                break;
            }

            // Empate por pase doble
            if (pasesConsecutivos >= 2) {
                System.out.println("Ambos jugadores pasaron consecutivamente. Empate.");
                System.out.println("Mesa final: " + mesa.toString());
                break;
            }

            System.out.println("Mesa ahora: " + mesa.toString());
            turnoHumano = !turnoHumano;
        }
    }

    public static void main(String[] args) {
        Domino juego = new Domino();
        juego.iniciarReparto();
        juego.jugar();
    }
}
