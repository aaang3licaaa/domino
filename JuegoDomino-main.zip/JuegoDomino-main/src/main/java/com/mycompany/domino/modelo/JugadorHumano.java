/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.domino.modelo;
import Negocio.Ficha;
import java.util.Scanner;

/**
 *
 * @author angelica
 */
/**
 * Jugador humano que juega mediante consola.
 * Muestra la mano con índices y solicita índice y extremo (L/R).
 */
public class JugadorHumano extends Jugador {
    private final Scanner scanner;

    public JugadorHumano(String nombre, Scanner scanner) {
        super(nombre);
        this.scanner = scanner;
    }

    @Override
    public boolean jugar(Mesa mesa) {
        // Si no tiene jugada, pasar
        if (!tieneJugada(mesa)) {
            System.out.println("No tienes jugada válida. Pasas.");
            return false;
        }

        while (true) {
            System.out.println("Mesa: " + mesa.toString());
            System.out.println("Tu mano: " + mano.listarConIndices());
            System.out.print("Ingrese índice de ficha a jugar o 'p' para pasar: ");
            String linea = scanner.nextLine().trim();
            if (linea.equalsIgnoreCase("p")) {
                System.out.println("Has decidido pasar.");
                return false;
            }
            int idx = -1;
            try {
                idx = Integer.parseInt(linea);
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Intenta nuevamente.");
                continue;
            }
            Ficha f = mano.obtener(idx);
            if (f == null) {
                System.out.println("Índice inválido. Intenta nuevamente.");
                continue;
            }
            System.out.print("Colocar en (L) izquierda o (R) derecha? [L/R]: ");
            String lado = scanner.nextLine().trim();
            boolean jugado = false;
            if (lado.equalsIgnoreCase("L")) {
                jugado = mesa.colocarIzquierda(f);
            } else if (lado.equalsIgnoreCase("R")) {
                jugado = mesa.colocarDerecha(f);
            } else {
                System.out.println("Opción inválida. Intenta nuevamente.");
                continue;
            }
            if (jugado) {
                // quitar de la mano (por índice)
                mano.quitarPorIndice(idx);
                System.out.println("Jugaste " + f + " en " + (lado.equalsIgnoreCase("L") ? "izquierda" : "derecha"));
                return true;
            } else {
                System.out.println("Esa ficha no puede colocarse en ese lado. Intenta otra jugada o pasa.");
            }
        }
    }
}